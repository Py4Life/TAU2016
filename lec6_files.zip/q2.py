import re


def parse_obo(path):
    """
        Returns a dictionary that matches each DO term ancestors to its id in the input obo file
    """

    pass #replace this line with your code


def is_ancestor(father, son, obo_filepath):
    """
        returns True if father is the direct ancestor of son, and False otherwise
    """
    pass #replace this line with your code


od_ancestors_dict = parse_obo("HumanDO.obo")
print(od_ancestors_dict["DOID:2649"])
print(od_ancestors_dict["DOID:265"])
print(od_ancestors_dict["DOID:2651"])

assert(is_ancestor("DOID:265", 'DOID:254', "HumanDO.obo")==False)
assert(is_ancestor("DOID:254", 'DOID:265', "HumanDO.obo")==True)
