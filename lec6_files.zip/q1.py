def couples_dictionary(n):
    '''
    The function returns a dictionary with keys and values as follows:
    - The keys are the integers between 2 and 2n (including both)
    - The values are lists, containing all the couples of integers 
      between 1 and n, whose sum equals to the key (treat the couples 
      [x,y] and [y,x] as different couples)
    '''
    
    pass #replace this line with your code
        
    
def calc_key_proportion(d):
    '''
    The function returns a new dictionary with the same keys, but instead 
    of the lists as values, the values would be the length of the list, 
    divided by the sum of the lengths of all lists 
    (the proportion of couples that their sum equals to the key).
    '''
    
    pass #replace this line with your code


def dice_prob(n,val):
    '''
    The fumction returns the answer to the following question: 
    what is the chance of getting val, when tossing two n-dice.
    Use the functions (a) and (b) in order to calculate the answer.
    '''
    pass #replace this line with your code