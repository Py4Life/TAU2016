import os
import csv


def csv_merge(path):
    """
        The function creates(!) a new csv file with the all 
        the data from the files in the path.
    """

    pass #replace this line with your code
    

def find_means(path,n,k,m,r):
    """
        The function returns the mean of the First Appearance and the mean 
        survival rate (mean of ext/fix), for the simulations with 
        same n,k,m,r values.
    """
    
    pass #replace this line with your code