def couples_dictionary(n):
    dic = {}
    for x in range(1, n+1):   	# first die
        for y in range(1, n+1): 	# second die
            couple = [x,y]
            couple_sum = x+y
            if couple_sum not in dic:
                dic[couple_sum] = [couple]
            else:
                combinations = dic[couple_sum] 
                combinations.append(couple)
                dic[couple_sum] = combinations
    return dic
    
def calc_key_proportion(d):
    new = {}
    combi_sum = 0
    for elem in d:
        combi_sum += len(d[elem])
    for elem in d:
        new[elem] = len(d[elem]) / combi_sum
    return new

def dice_prob(n,val):
    c_d = couples_dictionary(n)
    p   = proportion(c_d)
    return p[val]