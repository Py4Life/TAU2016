import os
import csv

def csv_merge(path):
    """
        Creates(!) a new csv file with all the data from the files in the path.
    """
    files = os.listdir(path)
    header = ['n','k','m','r','First Appearance','Finish','ext/fix']
    with open('summary.csv','w', newline='') as out:
        
        csv_writer = csv.writer(out)
        csv_writer.writerow(header)
        
        FA = []
        FI = []
        EF = []    
        
        for file in files:
            with open(path+'/'+file,'r') as f:
                csv_reader = csv.reader(f)
                for line in csv_reader:
                    if line[0] == 'n':
                        first = line[1::2]
                    else:
                        second = line
                FA.append(int(second[0]))
                FI.append(int(second[1]))
                EF.append(int(second[2]))
                
                csv_writer.writerow(first+second)
        
        csv_writer.writerow([])    
        csv_writer.writerow(['Mean First Appearance','Mean Finish', 'Fixation Probability'])
        csv_writer.writerow([sum(FA)/len(FA),sum(FI)/len(FI),sum(EF)/len(EF)])

def find_means(path,n,k,m,r):
    FA = []
    EF = []
    with open(path,'r') as f:
        csv_reader = csv.reader(f)
        for line in csv_reader:
            if line:
                if line[0] in ['2','5','10']:
                    if [float(line[0]),float(line[1]),float(line[2]),float(line[3])] == [n,k,m,r]:
                        FA.append(float(line[4]))
                        EF.append(float(line[6]))
    return sum(FA)/len(FA), sum(EF)/len(EF)