import re

def parse_obo(path):
    """
        Returns a dictionary that matches each DO term ancestors to its 
        id in the input obo file
    """

    DO_dict={}
    content = open(path, 'r')
    id_pattern = re.compile(r'^id')
    doid_pattern = re.compile(r'DOID:\d+')
    isa_pattern = re.compile(r'^is_a')
    line = content.readline()
    while line.strip() != "[Typedef]":
        if re.search(id_pattern, line):
            doid = re.search(doid_pattern, line).group()
            DO_dict[doid] = []
        elif re.search(isa_pattern, line):
            ancestor = re.search(doid_pattern, line).group()
            DO_dict[doid].append(ancestor)
        line = content.readline()
            
    return DO_dict


def is_ancestor(father, son, obo_filepath):
    """
        Returns True if father is the direct ancestor of son, 
        and False otherwise
    """
    DO_dict = parse_obo(obo_filepath)
    for ancestor in DO_dict[son]:
        if father == ancestor:
            return True
    return False

### tests ###
od_ancestors_dict = parse_obo("HumanDO.obo")
print(od_ancestors_dict["DOID:2649"])
print(od_ancestors_dict["DOID:265"])
print(od_ancestors_dict["DOID:2651"])

assert(is_ancestor("DOID:265", 'DOID:254', "HumanDO.obo")==False)
assert(is_ancestor("DOID:254", 'DOID:265', "HumanDO.obo")==True)
